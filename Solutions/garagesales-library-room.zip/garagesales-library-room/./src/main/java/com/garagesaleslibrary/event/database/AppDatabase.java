package com.garagesaleslibrary.event.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.garagesaleslibrary.event.domain.SaleEvent;

/**
 * Created by jamesharmon on 6/9/17.
 */

@Database(entities={SaleEvent.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract SaleEventDao saleEventDao();
}
