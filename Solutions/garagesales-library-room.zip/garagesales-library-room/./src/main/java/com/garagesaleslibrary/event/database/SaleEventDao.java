package com.garagesaleslibrary.event.database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.garagesaleslibrary.event.domain.SaleEvent;

import java.util.List;

/**
 * Created by jamesharmon on 6/9/17.
 */

@Dao
public interface SaleEventDao {

    @Query("SELECT * FROM sale_event")
    List<SaleEvent> getAll();

    @Insert
    void insertAll(SaleEvent... saleEvent);
}
