package com.garagesalesapp;

import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

public class EventMapActivity extends AppCompatActivity
		implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, GoogleMap.OnMarkerClickListener, LocationListener {

	private static final String TAG = EventMapActivity.class.getSimpleName();

	private GoogleMap mMap;

	private GoogleApiClient mGoogleApiClient;

	private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

	private Location mLastLocation;

	private LocationRequest mLocationRequest;
	private boolean mLocationUpdateState;

	private static final int REQUEST_CHECK_SETTINGS = 2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		Log.v(TAG, "Starting EventMap");
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.event_map);

        MapFragment mapFragment =
				(MapFragment) getFragmentManager().findFragmentById(R.id.map);

		mapFragment.getMapAsync(this);

		if (mGoogleApiClient == null) {
			mGoogleApiClient = new GoogleApiClient.Builder(this)
					.addConnectionCallbacks(this)
					.addOnConnectionFailedListener(this)
					.addApi(LocationServices.API)
					.build();
		}

	}

	private void displayMap() {
		// Center on Naperville, Illinois
		LatLng latLng = new LatLng(41.748276D, -88.129797D);

		CameraUpdate center = CameraUpdateFactory.newLatLng(latLng);

		mMap.moveCamera(center);

		CameraUpdate zoom = CameraUpdateFactory.zoomTo(11);

		mMap.animateCamera(zoom);

		displayMarkers();
	}

	private void displayMarkers() {
		List<SaleEvent> events = SaleEventManager.getAllEvents(this);
		for (SaleEvent event : events) {

			Double itemLat = event.getLatitude() * 1E6;
			Double itemLng = event.getLongitude() * 1E6;

			LatLng itemLatLng = new LatLng(itemLat, itemLng);

			Log.v(TAG, "Adding LatLng to event locations: " + itemLat + ", " + itemLng);

			MarkerOptions markerOptions = new MarkerOptions();
			markerOptions.position(new LatLng(event.getLatitude(), event.getLongitude()));

			markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.garage));

			markerOptions.title(event.getStreet() + ", " + event.getCity());

			mMap.addMarker(markerOptions);

		}
	}

	@Override
	public void onMapReady(GoogleMap googleMap) {
		mMap = googleMap;

		mMap.getUiSettings().setZoomControlsEnabled(true);
		mMap.setOnMarkerClickListener(this);

		//displayMap();
	}

	@Override
	public void onConnected(@Nullable Bundle bundle) {
		setUpMap();
	}

	@Override
	public void onConnectionSuspended(int i) {

	}

	@Override
	public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

	}

	@Override
	public void onLocationChanged(Location location) {

	}

	@Override
	public boolean onMarkerClick(Marker marker) {
		return false;
	}

	@Override
	protected void onStart() {
		super.onStart();
		mGoogleApiClient.connect();
	}

	@Override
	protected void onStop() {
		super.onStop();
		if( mGoogleApiClient != null && mGoogleApiClient.isConnected() ) {
			mGoogleApiClient.disconnect();
		}
	}

	private void setUpMap() {
		if (ActivityCompat.checkSelfPermission(this,
				android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this, new String[]
					{android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);

			// 1
			mMap.setMyLocationEnabled(true);

			LocationAvailability locationAvailability =
					LocationServices.FusedLocationApi.getLocationAvailability(mGoogleApiClient);
			if (null != locationAvailability && locationAvailability.isLocationAvailable()) {
				// 3
				mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
				// 4
				if (mLastLocation != null) {
					LatLng currentLocation = new LatLng(mLastLocation.getLatitude(), mLastLocation
							.getLongitude());
					mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 12));
				}
			}

			return;
		}
	}

	protected void startLocationUpdates() {
		if (ActivityCompat.checkSelfPermission(this,
				android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this,
					new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
					LOCATION_PERMISSION_REQUEST_CODE);
			return;
		}
		LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest,
				this);
	}

	protected void createLocationRequest() {
		mLocationRequest = new LocationRequest();

		mLocationRequest.setInterval(10000);

		mLocationRequest.setFastestInterval(5000);
		mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

		LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
				.addLocationRequest(mLocationRequest);

		PendingResult<LocationSettingsResult> result =
				LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient,
						builder.build());

		result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
			@Override
			public void onResult(@NonNull LocationSettingsResult result) {
				final Status status = result.getStatus();
				switch (status.getStatusCode()) {
					// 4
					case LocationSettingsStatusCodes.SUCCESS:
						mLocationUpdateState = true;
						startLocationUpdates();
						break;
					case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
						try {
							status.startResolutionForResult(EventMapActivity.this, REQUEST_CHECK_SETTINGS);
						} catch (IntentSender.SendIntentException e) {
						}
						break;
					case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
						break;
				}
			}
		});
	}
}