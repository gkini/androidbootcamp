package com.garagesalesapp;

import android.app.Application;
import android.arch.persistence.room.Room;

import com.garagesaleslibrary.event.database.AppDatabase;

public class GarageApplication extends Application {

    private static AppDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();

        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "garage.db")
                .allowMainThreadQueries()
                .build();
    }

    public static AppDatabase getDb() {
        return db;
    }
}
