package com.garagesaleslibrary.event.utils;

import android.content.Context;
import android.util.Log;
import android.util.Xml;

import com.garagesaleslibrary.event.domain.SaleEvent;

import org.xmlpull.v1.XmlSerializer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;

public class FileUtils {

    private static final String TAG = FileUtils.class.getSimpleName();

    public static String writeXml(SaleEvent event) {
        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        try {
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag("", "events");

            serializer.startTag("", "event");

            serializeTag(serializer, "id", event.getId());
            serializeTag(serializer, "date", event.getDate().toLocaleString());
            serializeTag(serializer, "title", event.getTitle());
            serializeTag(serializer, "street", event.getStreet());
            serializeTag(serializer, "city", event.getCity());
            serializeTag(serializer, "state", event.getState());
            serializeTag(serializer, "zip", event.getZip());
            serializeTag(serializer, "latitude", Double.toString(event.getLatitude()));
            serializeTag(serializer, "longitude", Double.toString(event.getLongitude()));
            serializeTag(serializer, "rating", Float.toString(event.getRating()));
            serializeTag(serializer, "description", event.getDescription());

            serializer.endTag("", "event");

            serializer.endTag("", "events");
            serializer.endDocument();
            return writer.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void serializeTag(XmlSerializer serializer, String tagName, String tagValue) throws IOException {
        serializer.startTag("", tagName);
        if (tagValue != null) {
            serializer.text(tagValue);
        }
        serializer.endTag("", tagName);
    }

    public static void writeFile(Context context, String fileName, String outputString) {
        FileOutputStream fos = null;
        try {
            fos = context.openFileOutput(fileName, Context.MODE_WORLD_READABLE);
            fos.write(outputString.getBytes());
            Log.v("EventService", "File written: " + fileName);
        } catch (FileNotFoundException e) {
            Log.e("SaleEventManager", "File not found", e);
            e.printStackTrace();
        } catch (IOException e) {
            Log.e("SaleEventManager", "IO problem", e);
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                Log.e("SaleEventManager", "IO problem", e);
                e.printStackTrace();
            } }
    }

    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
