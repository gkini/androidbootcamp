package com.garagesalesapp.service;

import java.util.ArrayList;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.garagesalesapp.MainActivity;
import com.garagesalesapp.domain.LocationEvent;

public class GetAllEventsTask extends AsyncTask<Context, Void, ArrayList<LocationEvent>> {

	private static final String TAG = GetAllEventsTask.class.getSimpleName();

	private MainActivity mainActivity;

	ProgressDialog pd;

	public GetAllEventsTask(MainActivity mainActivity) {
		this.mainActivity = mainActivity;
	}

	@Override
	protected void onPreExecute() {
		mainActivity.clearList();
		pd = new ProgressDialog(mainActivity);
		pd.setMessage("Loading Events ...");
		pd.show();
	}

	@Override
	protected ArrayList<LocationEvent> doInBackground(Context... params) {
		
//		try {
//			Log.v(TAG, "Thread sleep");
//			Thread.sleep(5000);
//			Log.v(TAG, "Thread awake");
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}

		Log.v(TAG, "Running doInBackground");
		ArrayList<LocationEvent> events = (ArrayList<LocationEvent>) EventService.getAllEvents();
		Log.v(TAG, "Completed doInBackground");
		return events;

	}

	@Override
	protected void onPostExecute(ArrayList<LocationEvent> events) {
		Log.v(TAG, "Running onPostExecute");
		mainActivity.setEvents(events);
		mainActivity.showList();
		mainActivity.removeTask();
		pd.hide();
		pd.dismiss();  // fixes problem with memory leak when exiting MainActivity
	}

}
