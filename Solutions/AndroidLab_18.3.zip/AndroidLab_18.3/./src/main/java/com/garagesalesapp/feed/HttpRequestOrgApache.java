package com.garagesalesapp.feed;

import android.util.Log;

import java.io.InputStream;


public class HttpRequestOrgApache implements XmlHttpRequest {
	
	private static final String TAG = "EventService";

	public InputStream getUrlResponse(String urlString) {
		Log.v(TAG, "Retrieving URL: " + urlString);
		InputStream in = null;
//		try {
//			DefaultHttpClient httpclient = new DefaultHttpClient();
//			HttpGet httpget = new HttpGet(urlString);
//			HttpResponse response = httpclient.execute(httpget);
//			HttpEntity entity = response.getEntity();
//			if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
//				in = entity.getContent();
//			}
//		} catch (IOException e) {
//			Log.v(TAG, "Unable to retrieve URL");
//			e.printStackTrace();
//		}

		return in;
	}

}
