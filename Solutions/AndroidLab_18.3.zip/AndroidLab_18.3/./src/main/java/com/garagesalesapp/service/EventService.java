package com.garagesalesapp.service;


import android.util.Log;
import android.util.Xml;

import com.garagesalesapp.GarageApplication;
import com.garagesalesapp.R;
import com.garagesalesapp.domain.LocationEvent;
import com.garagesalesapp.feed.EventXMLProcessor;
import com.garagesalesapp.feed.EventXMLProcessorAndroidSAX;
import com.garagesalesapp.feed.HttpRequestOrgApache;
import com.garagesalesapp.feed.XmlHttpRequest;

import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.List;

public class EventService {

	private static List<LocationEvent> events = null;

	private static final String TAG = EventService.class.getSimpleName();

	private static XmlHttpRequest request = new HttpRequestOrgApache();
	private static EventXMLProcessor parser = new EventXMLProcessorAndroidSAX();

	public static List<LocationEvent> processEventFeed(String urlString) {
		InputStream inputStream = request.getUrlResponse(urlString);
		return parser.processEventFeed(inputStream);
	}

	public static List<LocationEvent> getAllEvents() {
		try {
			Log.v(TAG, "Thread goes to sleep");
			Thread.sleep(2000);
			Log.v(TAG, "Thread wakes up");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (events == null) {
			// build events from XML file
			InputStream inputStream = GarageApplication.getAppContext().getResources().openRawResource(R.raw.naper_events);
			events = parser.processEventFeed(inputStream);
			for (LocationEvent event : events) {
				GarageApplication.getDbAdapter().open().insertEntry(event);
			}

		}
		events = GarageApplication.getDbAdapter().open().getAllEvents();
		return events;
	}

	public static void addEvent(LocationEvent event) {
		Log.v(TAG, " addEvent: " + event.getTitle());
		Log.v(TAG, "Number of events before add:" + events.size());
		GarageApplication.getDbAdapter().open().insertEntry(event);
		events.add(0, event);
	}

	public static String writeXml(LocationEvent event) {
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try {
			serializer.setOutput(writer);
			serializer.startDocument("UTF-8", true);
			serializer.startTag("", "events");

			serializer.startTag("", "event");

			serializeTag(serializer, "id", event.getId());
			serializeTag(serializer, "date", event.getDate().toLocaleString());
			serializeTag(serializer, "title", event.getTitle());
			serializeTag(serializer, "street", event.getStreet());
			serializeTag(serializer, "city", event.getCity());
			serializeTag(serializer, "state", event.getState());
			serializeTag(serializer, "zip", event.getZip());
//			serializeTag(serializer, "latitude", Double.toString(event.getLatitude()));
//			serializeTag(serializer, "longitude", Double.toString(event.getLongitude()));
//			serializeTag(serializer, "rating", Float.toString(event.getRating()));
			serializeTag(serializer, "description", event.getDescription());

			serializer.endTag("", "event");

			serializer.endTag("", "events");
			serializer.endDocument();
			return writer.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static void serializeTag(XmlSerializer serializer, String tagName, String tagValue) throws IOException {
		serializer.startTag("", tagName);
		if (tagValue != null) {
			serializer.text(tagValue);
		}
		serializer.endTag("", tagName);
	}
	
	public static void writeFile(String fileName, String output) {

	}
}
