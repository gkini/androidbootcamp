package com.garagesalesapp;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.garagesalesapp.database.GaragzeDbAdapter;

public class GarageApplication extends Application {
	
	private static GaragzeDbAdapter dbAdapter;

    private static Context context;

    public void onCreate(){
		super.onCreate();
    	Log.v("GarageApplication", "Creating application");
        GarageApplication.context = getApplicationContext();
        GarageApplication.dbAdapter = new GaragzeDbAdapter(context);
        GarageApplication.dbAdapter.open();
    }

    @Override
	public void onTerminate() {
		// TODO Auto-generated method stub
		super.onTerminate();
	}

	public static Context getAppContext() {
    	return context;
    }

	public static GaragzeDbAdapter getDbAdapter() {
		return dbAdapter;
	}

}