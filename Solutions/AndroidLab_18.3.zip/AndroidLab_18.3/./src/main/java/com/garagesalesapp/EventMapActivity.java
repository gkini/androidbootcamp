package com.garagesalesapp;


import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.garagesalesapp.domain.LocationEvent;
import com.garagesalesapp.service.EventService;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

public class EventMapActivity extends Activity
        implements LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        OnMapReadyCallback {

    private static final String TAG = EventMapActivity.class.getSimpleName();

    private EventService service = new EventService();

    Cursor eventCursor;

    Drawable drawable;

    GoogleApiClient mGoogleApiClient;

    final static int REQUEST_LOCATION = 199;

    GoogleMap map;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        Log.v(TAG, "Running onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_map);

        Log.v(TAG, "Building API Client");
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        mGoogleApiClient.connect();

        displayMap(-81000000, 40000000);

    }

    private void displayMap(double latitude, double longitude) {

        Log.v(TAG, "Displaying Map");

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);

        LatLng latLng = new LatLng(latitude, longitude);

        CameraUpdate center = CameraUpdateFactory.newLatLng(latLng);

        map.moveCamera(center);

        CameraUpdate zoom = CameraUpdateFactory.zoomTo(11);

        map.animateCamera(zoom);

        EventService service = new EventService();

        List<LocationEvent> events = service.getAllEvents();
        for (LocationEvent event : events) {

            Double itemLat = event.getLatitude() * 1E6;
            Double itemLng = event.getLongitude() * 1E6;

            Log.v(TAG, "Adding LatLng to event locations: " + itemLat + ", " + itemLng);

            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(new LatLng(event.getLatitude(), event.getLongitude()));
            markerOptions.title(event.getStreet() + ", " + event.getCity());

            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.garage));

            map.addMarker(markerOptions);

        }
    }

    private Location mLastLocation;

    @Override
    public void onConnected(Bundle bundle) {
        Log.d(TAG, "Location services connected");
        Location lastLocation = LocationServices
                .FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            double latitude = mLastLocation.getLatitude();
            double longitude = mLastLocation.getLongitude();
            Log.d(TAG, "Latitude: " + latitude);
            Log.d(TAG, "Longitude: " + longitude);
            displayMap(latitude, longitude);
        } else {
            Log.d(TAG, "Last location is null");
        }

        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        //mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);


        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Check Permissions Now
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION);
        } else {
            // permission has been granted, continue as usual
            LocationServices.FusedLocationApi
                    .requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);

        }

    }

    private LocationRequest mLocationRequest;

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            Log.d(TAG, "Latitude: " + latitude);
            Log.d(TAG, "Longitude: " + longitude);
            displayMap(latitude, longitude);

        } else {
            Log.d(TAG, "New location is null");
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "Location connection suspended");
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "Location connection failed");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d("MapsActivity", "ReadyMap");
        map = googleMap;
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            map.setMyLocationEnabled(true);
            //map.moveCamera(CameraUpdateFactory.newLatLng(FISCIANO));
            map.moveCamera(CameraUpdateFactory.zoomTo(15.0f));
        } else {
            Toast.makeText(getApplicationContext(), "Accetta i permessi", Toast.LENGTH_LONG).show();
        }
    }

}