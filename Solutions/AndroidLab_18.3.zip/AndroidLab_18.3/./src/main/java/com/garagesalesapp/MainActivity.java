package com.garagesalesapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.garagesalesapp.service.GetAllEventsTask;
import com.garagesalesapp.domain.LocationEvent;

import java.util.ArrayList;

public class MainActivity extends Activity {

	ArrayList<LocationEvent> events = new ArrayList<LocationEvent>();
	ArrayAdapter<LocationEvent> arrayAdapter = null;
	ListView listView;
	GetAllEventsTask task;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

	}


	public void clearList() {
		if (listView != null) {
			listView.setAdapter(null);
		}
	}

	public void showList() {
		// Build the adapter with whatever the current events are

		arrayAdapter = buildAdapter();
		listView = (ListView) findViewById(R.id.eventlistview);
		listView.setAdapter(arrayAdapter);
	}

	public void setEvents(ArrayList<LocationEvent> events) {
		this.events = events;
	}

	private ArrayAdapter<LocationEvent> buildAdapter() {
		final ArrayAdapter<LocationEvent> arrayAdapter = new EventArrayAdapter(this, R.layout.event_list_item, events);
		return arrayAdapter;
	}

	private void refreshList() {
		if (task != null) {
			return;
		}
		task = new GetAllEventsTask(this);
		task.execute(this);

		// why can't be rebuild the adapter
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
		case R.id.mi_add_event:
			addEvent();
			return true;
		case R.id.mi_show_map:
			showMap();
			return true;
		case R.id.mi_settings:
			showPrefs();
			return true;
		case R.id.mi_refresh:
			refreshList();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void showPrefs() {
		Log.v("MainActivity", "Running showPrefs method.");
		Intent intent = new Intent(this, SettingsActivity.class);
		startActivity(intent);
	}

	private void showMap() {
		Log.v("MainActivity ", "Running showMap method.");
        Intent intent = new Intent(this, EventMapActivity.class);
        startActivity(intent);
	}

	private void addEvent() {
		Log.v("MainActivity ", "Running addEvent method.");
		Intent intent = new Intent(this, AddEventActivity.class);
		startActivity(intent);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.v("MainActivity", "Running onDestroy method");
		removeTask();
	}

	@Override
	protected void onPause() {
		Log.v("MainActivity", "Running onPause method");
		super.onPause();
	}

	@Override
	protected void onRestart() {
		Log.v("MainActivity", "Running onRestart method");
		super.onRestart();
	}

	@Override
	protected void onResume() {
		Log.v("MainActivity", "Running onResume method");
		super.onResume();
		refreshList();
	}

	@Override
	protected void onStart() {
		Log.v("MainActivity", "Running onStart method");
		super.onStart();
	}

	@Override
	protected void onStop() {
		Log.v("MainActivity", "Running onStop method");
		super.onStop();
		if (task != null) {
			task.cancel(true);
		}
	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		Log.v("MainActivity", "Running onPostCreate method");
		super.onPostCreate(savedInstanceState);
	}

	@Override
	protected void onPostResume() {
		Log.v("MainActivity", "Running onPostResume method");
		super.onPostResume();
	}

	public void removeTask() {
		if (task != null) {
			task.cancel(true);
		}
		task = null;
	}

}