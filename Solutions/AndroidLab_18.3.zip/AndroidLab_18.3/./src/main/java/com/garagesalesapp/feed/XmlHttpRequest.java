package com.garagesalesapp.feed;

import java.io.InputStream;

public interface XmlHttpRequest {
	
	public InputStream getUrlResponse(String urlString);

}
