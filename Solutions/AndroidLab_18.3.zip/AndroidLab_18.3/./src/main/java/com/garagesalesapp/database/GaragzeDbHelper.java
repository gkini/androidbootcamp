package com.garagesalesapp.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class GaragzeDbHelper extends SQLiteOpenHelper {

	private static final String DATABASE_CREATE = "create table events (" + "_id integer primary key autoincrement, "
			+ "id text, " + "date date, " + "title text, " + "street text, " + "city text, " + "state text, "
			+ "zip text, " + "latitude double, " + "longitude double, " + "description text, " + "rating double, "
			+ "distance double " + ");";

	private static final String DATABASE_DROP = "drop table if exists events";

	@Override
	public void onCreate(SQLiteDatabase database) {
		Log.v("GaragzeDBHelper", "Create Table using " + DATABASE_CREATE);
		database.execSQL(DATABASE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
		Log.v("GaragzeDBHelper", "Drop Table, Upgrading from " + oldVersion + " to " + newVersion);
		database.execSQL(DATABASE_DROP);
		onCreate(database);
	}

	public GaragzeDbHelper(Context context, String name, CursorFactory factory, int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

}
