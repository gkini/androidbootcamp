package com.garagesalesapp.utils;

public class Constants {

    public static final String LOGTAG = "Garagze";

}
