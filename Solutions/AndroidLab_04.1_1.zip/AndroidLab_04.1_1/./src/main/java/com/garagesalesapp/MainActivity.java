package com.garagesalesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayListView();
    }

    private void displayListView() {
        // get all the data
        List<SaleEvent> events = SaleEventManager.getAllEvents(this);

        // convert the data to a list of String objects
        List<String> listData = new ArrayList<String>();
        for (SaleEvent event : events) {
            listData.add(event.getStreet());
        }

        // create the Adapter
        final ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);

        // get a reference to the ListView
        ListView listView = (ListView) findViewById(R.id.eventlistview);

        // inject the adapter into the ListView
        listView.setAdapter(arrayAdapter);

        // add a listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v(TAG, "User Clicked On ListView Position " + position);
                Toast.makeText(getApplicationContext(),
                        "Show ListView Position " + position, Toast.LENGTH_SHORT).show();
            }
        });



    }

    private int getEventCount() {
        return SaleEventManager.getAllEvents(this).size();
    }
}
