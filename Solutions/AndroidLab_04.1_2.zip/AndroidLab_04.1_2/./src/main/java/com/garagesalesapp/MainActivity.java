package com.garagesalesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayListView();
    }

    private void displayListView() {
        List<SaleEvent> events = SaleEventManager.getAllEvents(this);

        final ArrayAdapter<SaleEvent> arrayAdapter =
                new SaleEventArrayAdapter(this, R.layout.event_list_item, events);

        ListView listView = (ListView) findViewById(R.id.eventlistview);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "ListView Position " + position, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
