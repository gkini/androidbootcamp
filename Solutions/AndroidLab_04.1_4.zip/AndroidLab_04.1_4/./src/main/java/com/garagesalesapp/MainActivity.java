package com.garagesalesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayRecyclerView();
    }

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLinearLayoutManager;
    private SaleEventRecyclerAdapter mAdapter;

    private void displayRecyclerView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.eventlistview);
        // Build layout manager
        mLinearLayoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);

        List<SaleEvent> events = SaleEventManager.getAllEvents(this);
        mAdapter = new SaleEventRecyclerAdapter(this, events);
        mRecyclerView.setAdapter(mAdapter);
    }
}
