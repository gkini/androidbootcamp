package com.garagesalesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.garagesaleslibrary.event.service.SaleEventManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView eventCountText = (TextView) findViewById(R.id.textView);

        int eventCount = getEventCount();

        eventCountText.setText("Number of events: " + eventCount);
    }

    private int getEventCount() {
        return SaleEventManager.getAllEvents(this).size();
    }

}
