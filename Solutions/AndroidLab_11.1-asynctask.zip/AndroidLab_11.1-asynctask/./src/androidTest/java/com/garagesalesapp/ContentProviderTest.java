package com.garagesalesapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.ProviderTestCase2;

import com.garagesaleslibrary.event.database.GarageContentProvider;
import com.garagesaleslibrary.event.database.GarageContract;

public class ContentProviderTest extends ProviderTestCase2<GarageContentProvider> {

    public ContentProviderTest() {
        super(GarageContentProvider.class, GarageContract.AUTHORITY);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        getMockContentResolver().addProvider(GarageContract.AUTHORITY, getProvider());
    }

    public void testInsertSaleEvent() {

        ContentValues values = new ContentValues();

        values.put("title", "New garage sale");

        Uri uri = getMockContentResolver().insert(GarageContract.CONTENT_URI, values);

        Cursor cursor = getMockContentResolver().query(uri, null, null, null, null);
        assertEquals(1, cursor.getCount());
        // move to first row
        cursor.moveToNext();
        assertEquals("New garage sale", cursor.getString(cursor.getColumnIndex("title")));
    }

//    public void testQueryItem() {
//        Uri uri = Uri.withAppendedPath(StatusContract.CONTENT_URI, StatusContract.TABLE);
//        uri = Uri.withAppendedPath(uri, "???");
//        Cursor cursor = getMockContentResolver().query(uri, null, null, null, null);
//        assertEquals(1, cursor.getCount());
//        // move to first row
//        cursor.moveToNext();
//        assertEquals("My tweet", cursor.getString(cursor.getColumnIndex("message")));
//    }
}
