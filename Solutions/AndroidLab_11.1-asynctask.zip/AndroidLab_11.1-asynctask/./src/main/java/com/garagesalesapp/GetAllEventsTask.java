package com.garagesalesapp;

import android.app.ProgressDialog;
import android.os.AsyncTask;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

public class GetAllEventsTask
        extends AsyncTask<Void, Void, List<SaleEvent>> {

    private final String taskName;
    MainActivity activity;
    private ProgressDialog pd;

    public GetAllEventsTask(MainActivity activity, String taskName) {
        this.activity = activity;
        this.taskName = taskName;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pd = new ProgressDialog(activity);
        pd.setMessage("Loading Events ...");
        pd.show();
    }

    @Override
    protected List<SaleEvent> doInBackground(Void... params) {
        Thread.currentThread().setName(taskName);
        return SaleEventManager.getAllEvents(activity);
    }

    @Override
    protected void onPostExecute(List<SaleEvent> saleEvents) {
        activity.displayRecyclerView(saleEvents);
        activity.task = null;
        pd.hide();
        pd.cancel();
    }
}
