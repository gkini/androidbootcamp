package com.garagesalesapp;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

/**
 * Created by jamesharmon on 6/22/15.
 */
public class EventListFragment extends Fragment
        implements SaleEventRecyclerAdapter.OnItemClickListener {

    private static final String TAG = EventListFragment.class.getSimpleName();

    private OnEventSelectedListener listener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        RelativeLayout view =
                (RelativeLayout) inflater.inflate(R.layout.event_list, container, false);

        displayRecyclerView(view);

        return view;
    }

    private void displayRecyclerView(View view) {
        RecyclerView mRecyclerView = (RecyclerView) view.findViewById(R.id.eventlistview);
        // Build layout manager
        LinearLayoutManager mLinearLayoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        List<SaleEvent> events = SaleEventManager.getAllEvents(getActivity());
        SaleEventRecyclerAdapter mAdapter =
                new SaleEventRecyclerAdapter(getActivity(), events, this);
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onItemClick(SaleEvent saleEvent) {
        Log.d(TAG, "running listener in fragment");
        listener.onEventSelected(saleEvent);
    }

    public interface OnEventSelectedListener {
        public void onEventSelected(SaleEvent event);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            listener = (OnEventSelectedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    " must implement OnEventSelectedListener");
        }
    }

}
