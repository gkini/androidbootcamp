package com.garagesalesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

public class MainActivity extends AppCompatActivity
        implements EventListFragment.OnEventSelectedListener {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EventDetailFragment viewer = (EventDetailFragment)
                getSupportFragmentManager().findFragmentById(R.id.detail_fragment);
        if (viewer == null || !viewer.isInLayout()) {

        } else {
            viewer.update( SaleEventManager.getAllEvents(this).get(0));
        }
    }

    @Override
    public void onEventSelected(SaleEvent event) {
        Log.d(TAG, "Running eventSelected listener in activity_main activity");
        EventListFragment eventListFragment = (EventListFragment)
                getSupportFragmentManager().findFragmentById(R.id.list_fragment);
        EventDetailFragment viewer = (EventDetailFragment)
                getSupportFragmentManager().findFragmentById(R.id.detail_fragment);
        if (viewer == null || !viewer.isInLayout()) {
            Intent intent = new Intent(this, EventDetailActivity.class);
            intent.putExtra("street", event.getStreet());
            intent.putExtra("description", event.getDescription());
            startActivity(intent);
        } else {
            viewer.update(event);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.mi_add_event:
                addEvent();
                return true;
            case R.id.mi_show_map:
                showMap();
                return true;
            case R.id.mi_settings:
                showPrefs();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void showPrefs() {
        Log.v(TAG, "Running showPrefs method.");
    }

    private void showMap() {
        Log.v(TAG, "Running showMap method.");
    }

    private void addEvent() {
        Log.v(TAG, "Running addEvent method.");

        Intent intent = new Intent(this, AddEventActivity.class);
        startActivity(intent);
    }

}
