package com.garagesalesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.garagesaleslibrary.event.domain.SaleEvent;

public class EventDetailFragment extends Fragment {

    TextView street;
    TextView description;
    TextView city;
    TextView rating;
    TextView distance;

    CardView view;

    public static String TAG = EventDetailFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = (CardView) inflater.inflate(R.layout.event_detail, container, false);

        // get references to the view elements in the detail layout
        street = (TextView) view.findViewById(R.id.event_street);
        description = (TextView) view.findViewById(R.id.event_description);

        Intent intent = getActivity().getIntent();
        // Get the event data from the intent and update view
        street.setText(intent.getStringExtra("street"));
        description.setText(intent.getStringExtra("description"));

//        if (intent.getStringExtra("street") == null) {
//            view.setVisibility(View.INVISIBLE);
//        } else {
//            view.setVisibility(View.VISIBLE);
//        }

        return view;
    }

    public void update(SaleEvent event) {

        System.out.println("St: " + event.getStreet());
        System.out.println("Desc: " + event.getDescription());
        System.out.println("view: " + street);

        street.setText(event.getStreet());
        description.setText(event.getDescription());

        //view.setVisibility(View.VISIBLE);

    }

}
