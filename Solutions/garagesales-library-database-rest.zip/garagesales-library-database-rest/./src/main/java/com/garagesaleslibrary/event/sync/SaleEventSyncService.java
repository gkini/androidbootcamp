package com.garagesaleslibrary.event.sync;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

import java.util.List;

public class SaleEventSyncService extends IntentService {
    private static final String TAG = SaleEventSyncService.class.getSimpleName();

    public SaleEventSyncService() {
        super(SaleEventSyncService.class.getSimpleName());
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        Log.v(TAG, "Running method onHandleIntent");

        // get data from the cloud
        List<SaleEvent> newEvents
                = SaleEventRestManager.getNewEvents(this);
        for (SaleEvent event : newEvents) {
            Log.d(TAG, "Writing to local: " + event);
            SaleEventManager.addEvent(this, event);
            EventUpdateUtils.createNotification(getApplicationContext(), event.getStreet());

        }

        // put data into the cloud
        List<SaleEvent> unpostedEvents
                = SaleEventRestManager.getUnpostedEvents(this);
        for (SaleEvent event : unpostedEvents) {
            Log.d(TAG, "Writing to cloud: " + event);
            SaleEventRestManager.addEvent(event);
        }
    }
}