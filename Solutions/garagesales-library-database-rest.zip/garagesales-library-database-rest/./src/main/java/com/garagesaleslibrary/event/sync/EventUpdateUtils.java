package com.garagesaleslibrary.event.sync;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.garagesaleslibrary.event.R;

import java.util.Calendar;

/**
 * Created by jamesharmon on 3/22/16.
 */
public class EventUpdateUtils {

    private static final String TAG = EventUpdateUtils.class.getSimpleName();

    public static void scheduleEventUpdate(Context context) {

        // Get a reference to the alarm manager
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Log.v(TAG, "Creating alarm for event update");
        Intent intent =
                new Intent(context, EventUpdateBroadcastReceiver.class);
        int requestId = (int) System.currentTimeMillis();
        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(context.getApplicationContext(), requestId, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT);

        // We want the alarm to go off 15 seconds from now.
        Calendar startTime = Calendar.getInstance();
        startTime.setTimeInMillis(System.currentTimeMillis());
        startTime.add(Calendar.SECOND, 15);

        // Schedule the alarm, the alarm should repeat every 30 seconds
        int repeatSeconds = 10;
        alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, startTime.getTimeInMillis(),
                repeatSeconds * 1000, pendingIntent);
    }

    public static void createNotification(Context context, String eventStreet) {
        Log.v(TAG, "Creating notification");

        NotificationManager mNotificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Instantiate the Notification:
        int icon = R.drawable.notify;
        CharSequence tickerText = "New garage sale at " + eventStreet;
        long now = System.currentTimeMillis() + 5 * 60 * 1000;

        // Causes notification to be deleted when it is selected
        //notification.flags |= Notification.FLAG_AUTO_CANCEL;

        // Define the Notification's expanded message and Intent:
        CharSequence contentTitle = "New Garage Sale";
        CharSequence contentText = "Sale at " + eventStreet;

        Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.garagesalesapp");

        int requestId = (int) System.currentTimeMillis();
        PendingIntent pendingIntent =
                PendingIntent.getActivity(context, requestId, intent, 0);

        // Pass the Notification to the NotificationManager:
        int notificationId = (int) System.currentTimeMillis();
        notificationId = 1;

        Notification.Builder mBuilder =
                new Notification.Builder(context)
                        .setSmallIcon(icon)
                        .setContentTitle("New Garage Sale")
                        .setContentText("Sale at " + eventStreet)
                        .setTicker(tickerText)
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

        Notification notification = mBuilder.build();

        mNotificationManager.notify(notificationId, notification);
    }
}
