package com.garagesaleslibrary.event.service;

import android.content.Context;
import android.util.Log;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.utils.FileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class SaleEventRestManager implements SaleEventManagerInterface {

    private static final String TAG = SaleEventRestManager.class.getSimpleName();

    public static List<SaleEvent> getAllEvents() {
        Log.v(TAG, "Running getAllEvents");
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        String readEventFeed = readEventFeed();
        return parseJson(readEventFeed);
    }

    public static void updateEvent(Context context, SaleEvent event) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public static void deleteEvent(String eventId) {
        try {

            String urlString =
                    String.format("https://garagesalesapp.firebaseio.com/zzz/events/%s/event.json", eventId);

            URL url = new URL(urlString);

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("DELETE");
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String response = FileUtils.convertStreamToString(in);
            Log.d(TAG, "Response Code: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addEvent(SaleEvent event) {

        try {
            JSONObject json = new JSONObject();

            if (event.getId() == null || event.getId().equals("")) {
                event.setId(UUID.randomUUID().toString());
            }

            json.put("_id", event.getId());
            json.put("id", event.getId());
            json.put("street", event.getStreet());
            json.put("description", event.getDescription());
            json.put("city", event.getCity());
            json.put("title", event.getTitle());
            json.put("rating", event.getRating());
            json.put("imageFileName", event.getImageFileName());

            String urlString =
                    String.format("https://garagesalesapp.firebaseio.com/zzz/events/%s/event.json", event.getId());

            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("PUT");

            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            String output = json.toString();
            writer.write(output);
            writer.flush();
            writer.close();

            // read the response

            InputStream input = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            Log.d("doInBackground(Resp)", result.toString());
            JSONObject response = new JSONObject(result.toString());

            conn.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String readEventFeed() {
        StringBuilder builder = new StringBuilder();
        try {
            URL url =
                    new URL("https://garagesalesapp.firebaseio.com/zzz/events.json");
            HttpURLConnection urlConnection = (HttpURLConnection) url.
                    openConnection();
            // check response code from server
            int response = urlConnection.getResponseCode();
            Log.d(TAG, "Http Response: " + response);
            InputStream content =
                    new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    content));
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }

    private static List<SaleEvent> parseJson(String eventFeed) {
        Log.d(TAG, "Response: " + eventFeed);
        List<SaleEvent> events = new ArrayList<SaleEvent>();
        try {

            JSONObject json = new JSONObject(eventFeed);

            Iterator itr = json.keys();
            while (itr.hasNext()) {

                String key = (String) itr.next();

                Log.d(TAG, "Key: " + key);

                JSONObject eventHolder = json.getJSONObject(key);
                JSONObject jsonObject = eventHolder.getJSONObject("event");

                System.out.println("Event: " + jsonObject.toString());

                // create event object here
                SaleEvent event = new SaleEvent();

                try {
                    event.setId(jsonObject.getString("_id"));
                    event.setStreet(jsonObject.getString("street"));
                    event.setDescription(jsonObject.getString("description"));
                    event.setCity(jsonObject.getString("city"));
                    event.setTitle(jsonObject.getString("title"));
                    event.setRating(Float.parseFloat(jsonObject.getString("rating")));

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                events.add(event);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return events;
    }

    public static List<SaleEvent> getNewEvents(Context context) {
        List<SaleEvent> localEvents = SaleEventManager.getAllEvents(context);
        List<SaleEvent> cloudEvents = SaleEventRestManager.getAllEvents();
        cloudEvents.removeAll(localEvents);
        return cloudEvents;
    }

    public static List<SaleEvent> getUnpostedEvents(Context context) {
        List<SaleEvent> localEvents = SaleEventManager.getAllEvents(context);
        List<SaleEvent> cloudEvents = SaleEventRestManager.getAllEvents();
        localEvents.removeAll(cloudEvents);
        return localEvents;
    }
}
