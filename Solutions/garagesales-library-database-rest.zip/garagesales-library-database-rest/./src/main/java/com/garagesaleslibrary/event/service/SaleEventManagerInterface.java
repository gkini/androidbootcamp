package com.garagesaleslibrary.event.service;

/**
 * Created by jamesharmon on 3/9/15.
 */
public interface SaleEventManagerInterface {

}
