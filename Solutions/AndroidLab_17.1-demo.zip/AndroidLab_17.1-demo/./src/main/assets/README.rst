RSS Reader using Google Feeds API
=================================

This is a single page application to fetch RSS feeds using Google Feeds API. Responsive UI layout (Foundation) is used to make UI responsive on different devices. 
