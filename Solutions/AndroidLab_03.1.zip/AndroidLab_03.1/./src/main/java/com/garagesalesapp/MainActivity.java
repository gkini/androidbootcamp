package com.garagesalesapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.garagesaleslibrary.event.service.SaleEventManager;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView eventCountText = (TextView) findViewById(R.id.textView);

        int eventCount = getEventCount();

        eventCountText.setText("Number of events: " + eventCount);
    }

    private int getEventCount() {
        return SaleEventManager.getAllEvents(this).size();
    }

}
