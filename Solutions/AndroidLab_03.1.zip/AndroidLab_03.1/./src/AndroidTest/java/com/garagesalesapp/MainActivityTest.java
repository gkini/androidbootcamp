package com.garagesalesapp;

import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.util.Log;
import android.widget.TextView;

public class MainActivityTest extends ActivityInstrumentationTestCase2<MainActivity> {

	private static final String TAG = MainActivity.class.getSimpleName();

	public MainActivityTest() {
		super(MainActivity.class);
    }

	MainActivity mainActivity;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mainActivity = getActivity();
		Log.d(TAG, "Running setUp");
	}

	public void testActivityUI() {
		TextView textView =
                (TextView) mainActivity.findViewById(R.id.textView);
		assertEquals("Number of events: 15", textView.getText().toString());
	}

    public void testListView() {
        //ListView listView = (ListView) mainActivity.findViewById(R.id.event_count);
        //assertEquals("Number of events: 15", listView.getAdapter().getCount());
    }

	@UiThreadTest
	public void testViewElementAnnotation() {
		System.out.println(mainActivity);

		TextView textView = (TextView) mainActivity.findViewById(R.id.textView);
		textView.setText("abs");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertEquals("abc", textView.getText().toString());
	}
}
