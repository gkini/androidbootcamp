package com.garagesalesapp;

import android.test.AndroidTestCase;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by jamesharmon on 3/17/16.
 */
public class PutTest extends AndroidTestCase {

    public void testPut() {

        try {
            JSONObject json = new JSONObject();

            json.put("_id","103");
            json.put("street", "103 Main St");

            URL url = new URL("https://garagesalesapp.firebaseio.com/events/103/event.json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("PUT");

            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            String output = json.toString();
            writer.write(output);
            writer.flush();
            writer.close();

            // read the response

            InputStream input = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            Log.d("doInBackground(Resp)", result.toString());
            JSONObject response = new JSONObject(result.toString());

            conn.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
