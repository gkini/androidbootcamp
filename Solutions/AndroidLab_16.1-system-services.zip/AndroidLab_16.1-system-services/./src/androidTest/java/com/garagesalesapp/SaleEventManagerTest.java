package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class SaleEventManagerTest {

    @Test
    public void testJsonParsing() {
        SaleEventRestManager manager = new SaleEventRestManager();
        List<SaleEvent> events = manager.getAllEvents();

        for (SaleEvent event : events) {
            System.out.println(event.getStreet());
        }
        assertEquals(15, events.size());
    }

}