package com.garagesalesapp;

import android.test.AndroidTestCase;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by jamesharmon on 3/17/16.
 */
public class DeleteTest extends AndroidTestCase {

    private static final String TAG = DeleteTest.class.getSimpleName();

    public void testDelete() {

        try {

            String id = "4161";

            String urlString = String.format("https://garagesalesapp.firebaseio.com/events/%s/event.json", id);

            URL url = new URL(urlString);

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("DELETE");
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String response = TestUtil.convertStreamToString(in);
            Log.d(TAG, "Response: " + response);
            assertNotNull(response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
