package com.garagesalesapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by jamesharmon on 6/22/15.
 */
public class EventDetailActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_detail);

        // get references to the view elements in the detail layout
        TextView street = (TextView) findViewById(R.id.event_street);
        TextView description = (TextView) findViewById(R.id.event_description);

        Intent intent = getIntent();
        // Get the event data from the intent and update view
        street.setText(intent.getStringExtra("street"));
        description.setText(intent.getStringExtra("description"));
    }
}
