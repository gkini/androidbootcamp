package com.garagesalesapp;

import android.app.ProgressDialog;
import android.os.AsyncTask;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

public class GetAllEventsTask extends AsyncTask<Void, Void, List<SaleEvent>> {

    MainActivity activity;
    private ProgressDialog pd;

    public GetAllEventsTask(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pd = new ProgressDialog(activity);
        pd.setMessage("Loading Events ...");
        pd.show();
    }

    @Override
    protected List<SaleEvent> doInBackground(Void... params) {
        return SaleEventManager.getAllEvents(activity);
    }

    @Override
    protected void onPostExecute(List<SaleEvent> saleEvents) {
        activity.setEvents(saleEvents);
        activity.showList();
        activity.task = null;
        pd.hide();
        pd.cancel();
    }
}
