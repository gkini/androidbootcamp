package com.garagesalesapp;

import android.app.Application;
import android.util.Log;

import com.garagesaleslibrary.event.sync.EventUpdateUtils;


public class GarageApplication extends Application {

    private static final String TAG = GarageApplication.class.getSimpleName();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "running onCreate");
        EventUpdateUtils.scheduleEventUpdate(getApplicationContext());
    }
}
