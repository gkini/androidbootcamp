package com.garagesalesapp;

import android.app.Application;
import android.util.Log;

import com.garagesaleslibrary.event.database.GarageDbAdapter;

public class GarageApplication extends Application {

    private static final String TAG = GarageApplication.class.getSimpleName();
    private static GarageDbAdapter dbAdapter;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "running onCreate");

        GarageApplication.dbAdapter = new GarageDbAdapter(getApplicationContext());
        GarageApplication.dbAdapter.open();
    }

    public static GarageDbAdapter getDbAdapter() {
        return dbAdapter;
    }
}
