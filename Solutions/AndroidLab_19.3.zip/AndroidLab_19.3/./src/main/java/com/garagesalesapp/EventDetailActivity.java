package com.garagesalesapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.transition.Explode;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by jamesharmon on 6/22/15.
 */
public class EventDetailActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // inside your activity (if you did not enable transitions in your theme)
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);

        // set an exit transition
        getWindow().setExitTransition(new Explode());

        setContentView(R.layout.event_detail);

        // get references to the view elements in the detail layout
        TextView street = (TextView) findViewById(R.id.event_street);
        TextView description = (TextView) findViewById(R.id.event_description);
        ImageView image = (ImageView) findViewById(R.id.event_image);

        Intent intent = getIntent();
        // Get the event data from the intent and update view
        street.setText(intent.getStringExtra("street"));
        description.setText(intent.getStringExtra("description"));
        String imageFileName = intent.getStringExtra("image");

        image.setImageBitmap(Utils.getImage(this, imageFileName));
    }
}
