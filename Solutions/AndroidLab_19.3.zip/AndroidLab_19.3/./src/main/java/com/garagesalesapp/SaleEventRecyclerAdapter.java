package com.garagesalesapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.garagesaleslibrary.event.domain.SaleEvent;

import java.util.Collections;
import java.util.List;

public class SaleEventRecyclerAdapter
        extends RecyclerView.Adapter<SaleEventRecyclerAdapter.ViewHolder> {

    private static final String TAG = SaleEventRecyclerAdapter.class.getSimpleName();

    Context mContext;
    List<SaleEvent> events;
    OnItemClickListener listener;

    public SaleEventRecyclerAdapter(Context context, List<SaleEvent> events, OnItemClickListener listener) {
        this.mContext = context;
        this.events = events;
        this.listener = listener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView address;
        public RatingBar rating;
        public TextView distance;
        public ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            address = (TextView) itemView.findViewById(R.id.item_address);
            rating = (RatingBar) itemView.findViewById(R.id.item_rating);
            distance = (TextView) itemView.findViewById(R.id.item_distance);
            image = (ImageView) itemView.findViewById(R.id.event_image);
        }

        public void bindListener(final SaleEvent saleEvent, final OnItemClickListener listener) {
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(saleEvent, v);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view =
                LayoutInflater.
                        from(parent.getContext()).
                        inflate(R.layout.event_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final SaleEvent event = events.get(position);
        holder.address.setText(event.getStreet() + ", " + event.getCity());
        holder.rating.setRating(event.getRating());
        holder.distance.setText(Double.toString(event.getDistance()));

        if(event.getImageFileName() != null) {
            holder.image.setImageBitmap(Utils.getImage(mContext, event.getImageFileName()));
        }else{
            holder.image.setImageBitmap(null);
        }

        holder.bindListener(event, listener);
    }


    public interface OnItemClickListener {
        void onItemClick(SaleEvent saleEvent, View view);
    }

    public void swap(int firstPosition, int secondPosition) {
        String logMsg = "BEFORE SWAPED method. : " + events;
        Log.v(TAG, logMsg);
        Collections.swap(events, firstPosition, secondPosition);
        logMsg = "After SWAPED method. : " + events;
        Log.v(TAG, logMsg);
        notifyItemMoved(firstPosition, secondPosition);
    }

}
