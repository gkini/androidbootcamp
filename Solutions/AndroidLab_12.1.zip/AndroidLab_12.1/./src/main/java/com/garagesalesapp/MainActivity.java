package com.garagesalesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.garagesaleslibrary.event.domain.SaleEvent;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    List<SaleEvent> events;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLinearLayoutManager;
    private SaleEventRecyclerAdapter mAdapter;

    private void displayRecyclerView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.eventlistview);
        // Build layout manager
        mLinearLayoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);

        mAdapter = new SaleEventRecyclerAdapter(this, events, new
                SaleEventRecyclerAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(SaleEvent saleEvent) {
                        Intent intent = new Intent(getBaseContext(), EventDetailActivity.class);
                        intent.putExtra("street", saleEvent.getStreet());
                        intent.putExtra("description", saleEvent.getDescription());
                        startActivity(intent);
                    }
                });
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.mi_add_event:
                addEvent();
                return true;
            case R.id.mi_show_map:
                showMap();
                return true;
            case R.id.mi_settings:
                showPrefs();
                return true;
            case R.id.mi_refresh:
                refresh();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public GetAllEventsTask task = null;

    private void refresh() {
        Log.v(TAG, "running refresh method.");
        events = new ArrayList<SaleEvent>();
        displayRecyclerView();
        if (task == null){
            task = new GetAllEventsTask(this);
            task.execute();
        }

    }

    private void showPrefs() {
        Log.v(TAG, "running showPrefs method.");
    }

    private void showMap() {
        Log.v(TAG, "running showMap method.");
    }

    private void addEvent() {
        Log.v(TAG, "Running addEvent method.");

        Intent intent = new Intent(this, AddEventActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("MainActivity", "Running onResume method");
        refresh();
    }


    public void setEvents(List<SaleEvent> events) {
        this.events = events;
    }

    public void showList() {
        displayRecyclerView();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (task != null){
            task.cancel(true);
        }
    }
}
