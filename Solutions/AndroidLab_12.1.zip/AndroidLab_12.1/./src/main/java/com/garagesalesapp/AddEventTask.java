package com.garagesalesapp;

import android.os.AsyncTask;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

public class AddEventTask extends AsyncTask<SaleEvent, Void, Void> {

    @Override
    protected Void doInBackground(SaleEvent... params) {
        SaleEvent event = (SaleEvent) params[0];
        SaleEventRestManager.addEvent(event);
        return null;
    }

}
