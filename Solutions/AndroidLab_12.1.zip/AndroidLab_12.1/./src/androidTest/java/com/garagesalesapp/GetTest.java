package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.utils.FileUtils;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

import static org.junit.Assert.assertNotNull;

@RunWith(AndroidJUnit4.class)
public class GetTest {

    @Test
    public void testGet() {

        try {

            String id = "103";

            String urlString = String.format("https://garagesalesapp.firebaseio.com/events/%s/event.json", id);

            URL url = new URL(urlString);

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String response = FileUtils.convertStreamToString(in);
            System.out.println(response);
            assertNotNull(response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetAll() {

        try {
            URL url = new URL("https://garagesalesapp.firebaseio.com/events.json");

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String response = FileUtils.convertStreamToString(in);
            System.out.println(response);
            assertNotNull(response);

            JSONObject json = new JSONObject(response);

            Iterator itr = json.keys();
            while(itr.hasNext()) {
                String key = (String) itr.next();
                System.out.println("key: " + key);
                JSONObject eventHolder = json.getJSONObject(key);
                System.out.println("eventHolder: " + eventHolder);
                JSONObject event = eventHolder.getJSONObject("event");
                System.out.println("event: " + event);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
