package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class RestTest {

    @Test
    public void testGetAllEvents() {
        List<SaleEvent> events =  SaleEventRestManager.getAllEvents();
        assertTrue(events.size() > 0);
    }
}
