package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.garagesaleslibrary.event.domain.SaleEvent;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@RunWith(AndroidJUnit4.class)
public class PutTest {

    @Test
    public void testPut() {

        try {
            SaleEvent event = new SaleEvent();
            event.setId("jim-from-chicago");

            JSONObject json = new JSONObject();

            json.put("_id",event.getId());
            json.put("street", "103 Main St");
            json.put("description", "Sports memorabilia");
            json.put("city","Naperville");

            URL url = new URL("https://garagesalesapp.firebaseio.com/events/jim-from-chicago/event.json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("PUT");

            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            String output = json.toString();
            writer.write(output);
            writer.flush();
            writer.close();

            // read the response

            InputStream input = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            Log.d("doInBackground(Resp)", result.toString());
            JSONObject response = new JSONObject(result.toString());

            conn.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
