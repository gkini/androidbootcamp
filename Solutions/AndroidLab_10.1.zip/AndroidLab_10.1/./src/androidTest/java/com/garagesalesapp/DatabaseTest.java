package com.garagesalesapp;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.database.GarageDbAdapter;
import com.garagesaleslibrary.event.domain.SaleEvent;

import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class DatabaseTest {

    @Test
    public void testInsertEvent() {
        Context context = InstrumentationRegistry.getTargetContext();

        GarageDbAdapter adapter = new GarageDbAdapter(context);

        SaleEvent event = new SaleEvent();
        event.setId("1001");
        event.setStreet("123 Main Street");
        adapter.open().insertSaleEvent(event);

        SaleEvent returnedEvent = adapter.open().getEvent("1001");
        assertEquals("123 Main Street", returnedEvent.getStreet());

    }

}
