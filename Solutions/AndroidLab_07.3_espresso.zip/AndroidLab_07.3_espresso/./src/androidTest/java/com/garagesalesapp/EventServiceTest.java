package com.garagesalesapp;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class EventServiceTest {

    @Test
	public void testGetAllEvents() {

        Context context = InstrumentationRegistry.getTargetContext();

        List<SaleEvent> events = SaleEventManager.getAllEvents(context);

        // compare to expected results;

        assertTrue(events.size() > 0);

		assertEquals(15, events.size());

	}

}
