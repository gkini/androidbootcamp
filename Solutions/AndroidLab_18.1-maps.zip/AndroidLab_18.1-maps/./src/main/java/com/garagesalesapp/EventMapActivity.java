package com.garagesalesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

public class EventMapActivity extends AppCompatActivity implements OnMapReadyCallback {

	private static final String TAG = EventMapActivity.class.getSimpleName();

	private GoogleMap map;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.event_map);

        MapFragment mapFragment =
				(MapFragment) getFragmentManager().findFragmentById(R.id.map);

		mapFragment.getMapAsync(this);
	}

	private void displayMap() {

		// Center on Naperville, Illinois
		LatLng latLng = new LatLng(41.748276D, -88.129797D);

		CameraUpdate center = CameraUpdateFactory.newLatLng(latLng);

		map.moveCamera(center);

		CameraUpdate zoom = CameraUpdateFactory.zoomTo(11);

		map.animateCamera(zoom);
	}

	@Override
	public void onMapReady(GoogleMap googleMap) {
		map = googleMap;
		displayMap();
	}

}