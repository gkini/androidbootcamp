package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class SaleEventRestManagerTest {

    @Test
    public void getAllEvents() {
        List<SaleEvent> events = SaleEventRestManager.getAllEvents();

        for (SaleEvent event : events) {
            System.out.println(event.getId() + ": " + event.getStreet());
        }

        assertTrue(events.size() > 0);
        assertEquals(3, events.size());
    }

    @Test
    public void addEvent() {
        SaleEvent event = new SaleEvent();
        event.setStreet("123 Main St.");
        event.setDescription("Lots of stuff");
        SaleEventRestManager.addEvent(event);
    }

    @Test
    public void deleteEvent() {
        SaleEvent event = new SaleEvent();
        event.setStreet("123 Main St.");
        event.setDescription("Lots of stuff");
        SaleEventRestManager.deleteEvent("123");
    }


}