package com.garagesalesapp;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;
import com.garagesaleslibrary.event.service.SaleEventRestManager;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class BuildTestData {

    @Test
    public void deleteAllData() {
        // Delete all data
        List<SaleEvent> events = SaleEventRestManager.getAllEvents();
        for (SaleEvent event : events) {
            SaleEventRestManager.deleteEvent(event.getId());
        }
    }

    @Test
    public void addTestData() {
        // Create new data
        Context context = InstrumentationRegistry.getTargetContext();
        List<SaleEvent> addEvents = SaleEventManager.getAllEvents(context);
        for (SaleEvent event : addEvents) {
            SaleEventRestManager.addEvent(event);
        }
    }

}