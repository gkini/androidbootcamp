package com.garagesalesapp;

import android.support.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@RunWith(AndroidJUnit4.class)
public class OkHttpTest {

    @Test
    public void getAllEventsWithOkHttp() {

        String json = "";
        try {
            json = run("https://garagesalesapp.firebaseio.com/events.json");
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(json);

    }

    static String run(String url) throws IOException {

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
        return response.body().string();
    }

}