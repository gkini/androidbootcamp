package com.garagesaleslibrary.event.service;


import android.content.Context;
import android.util.Log;

import com.garagesaleslibrary.event.R;
import com.garagesaleslibrary.event.database.GarageDbAdapter;
import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.feed.EventXMLProcessor;

import java.io.InputStream;
import java.util.List;

public class SaleEventManager implements SaleEventManagerInterface {

    private static final String TAG = "EventService";

    public static List<SaleEvent> getAllEvents(Context context) {
        GarageDbAdapter adapter = new GarageDbAdapter(context);
        return adapter.open().getAllSaleEvents();
    }

    public static List<SaleEvent> parseSaleEventXmlFile(Context context) {

        EventXMLProcessor parser = new com.garagesaleslibrary.event.feed.EventXMLProcessorAndroidSAX();
        InputStream inputStream = context.getResources().openRawResource(R.raw.naper_events);
        List<SaleEvent> saleEvents = parser.processEventFeed(inputStream);
        return saleEvents;
    }

    public static void updateEvent(Context context, SaleEvent event) {
        throw new UnsupportedOperationException();
    }

    public static void addEvent(Context context, SaleEvent event) {

        Log.d(TAG, "running addEvent");

        event.setId(java.util.UUID.randomUUID().toString());
        event.setDate(new java.util.Date());

        GarageDbAdapter adapter = new GarageDbAdapter(context);
        adapter.open().insertSaleEvent(event);
    }
}
