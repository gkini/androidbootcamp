package com.garagesaleslibrary.event.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.garagesaleslibrary.event.domain.SaleEvent;
import com.garagesaleslibrary.event.service.SaleEventManager;

import java.util.List;

public class GarageDbHelper extends SQLiteOpenHelper {

    private static final String TAG = GarageDbHelper.class.getSimpleName();

    Context context;

    public GarageDbHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        this.context = context;
    }

    private static final String DATABASE_CREATE =
            "create table " + GarageContract.TABLE + " (" +
                    "_id integer primary key autoincrement, " +
                    "id text, " +
                    "date date, " +
                    "title text, " +
                    "street text, " +
                    "city text, " +
                    "state text, " +
                    "zip text, " +
                    "latitude double, " +
                    "longitude double, " +
                    "description text, " +
                    "rating double, " +
                    "distance double " +
                    ");";

    public static final String DROP_TABLE = "drop table if exists events";

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.v(TAG, "Create Table using: " + DATABASE_CREATE);
        db.execSQL(DATABASE_CREATE);

        populateDatabase(db);
    }

    private void populateDatabase(SQLiteDatabase db) {
        List<SaleEvent> events = SaleEventManager.parseSaleEventXmlFile(context);
        for (SaleEvent event: events) {
            ContentValues values = new ContentValues();

            values.put("id", event.getId());
            if (event.getDate() != null) {
                values.put("date", Long.toString(event.getDate().getTime()) );
            }
            values.put("title", event.getTitle());
            values.put("street", event.getStreet());
            values.put("city", event.getCity());
            values.put("rating", event.getRating());
            values.put("distance", event.getDistance());
            values.put("description", event.getDescription());
            values.put("latitude", event.getLatitude());
            values.put("longitude", event.getLongitude());

            Log.v(TAG, "Insert event:id="+event.getId());

            db.insert("events", null, values);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.v(TAG, "Drop table using: " + DROP_TABLE);
        db.execSQL(DROP_TABLE);
        db.execSQL(DATABASE_CREATE);
    }
}
